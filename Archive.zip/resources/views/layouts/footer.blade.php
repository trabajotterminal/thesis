<section class="section-copyrights sec-moreless-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12"> <span class="text-white">Derechos reservados, Instituto Politécnico Nacional.</span></div>
        </div>
    </div>
</section>
