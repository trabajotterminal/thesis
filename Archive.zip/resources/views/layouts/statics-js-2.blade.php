<script src="{{ URL::asset('/js/jquery.min.js')}}"></script>
<script src="{{ URL::asset('/js/jquery-ui.js')}}"></script>
<script src="{{ asset('/js/scrolltotop/totop.js')}}"></script>
<script src="{{ asset('/js/category.js')}}"></script>

