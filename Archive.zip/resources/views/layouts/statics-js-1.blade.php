<script src="{{ URL::asset('/js/bootstrap/bootstrap.min.js')}}"></script>
<script src="{{ URL::asset('/js/jquery.min.js')}}"></script>
<script src="{{ URL::asset('/js/jquery-ui.js')}}"></script>
<script src="{{ URL::asset('/js/scrolltotop/totop.js')}}"></script>
<script src="{{ URL::asset('/js/index.js')}}"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>
