<?php $__env->startSection('title', 'Estadisticas'); ?>

<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <style>body{overflow-x: hidden;}</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'login'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row" style="min-height:550px;">
        <div class="col-md-6">
            <h3 class="margin-left-2 margin-top3">Estadisticas grupales para: <?php echo e($group_name); ?></h3>
        </div>
        <div class="col-md-6">
            <div class="form-group margin-top4">
                <label class="col-sm-2 control-label"> Filtro: </label>
                <div class="col-sm-10">
                    <select class="form-control" id="filter" style="width:250px;">
                        <option value="0" selected>Teoría</option>
                        <option value="1">Cuestionarios</option>
                        <option value="2">Simulaciones</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-12">
            <div id="group_statistics_theory"></div>
        </div>
        <div class="col-md-12">
            <div id="group_statistics_simulation"></div>
        </div>
        <div class="col-md-12">
            <div id="group_statistics_questionnaire"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <script src="<?php echo e(asset('js/progress-circle/jquery.circlechart.js')); ?>"></script>
    <script src="<?php echo e(asset('js/universal/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/canvas.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            var url = "<?php echo e(url('/admin/group/statistics/' . $group_name . '/theory')); ?>";
            $("#filter").val('0');
            $('#group_statistics_simulation').hide();
            $('#group_statistics_questionnaire').hide();
            $('#group_statistics_theory').load(encodeURI(url), function(){}).hide().fadeIn();
        });
        $('#filter').on('change', function() {
            var index = this.value;
            if(index == 0){
                var url = "<?php echo e(url('/admin/group/statistics/' . $group_name . '/theory')); ?>";
                $('#group_statistics_simulation').hide();
                $('#group_statistics_questionnaire').hide();
                $('#group_statistics_theory').load(encodeURI(url), function(){}).hide().fadeIn();
            }
            if(index == 1){
                var url = "<?php echo e(url('/admin/group/statistics/' . $group_name . '/questionnaire')); ?>";
                $('#group_statistics_simulation').hide();
                $('#group_statistics_theory').hide();
                $('#group_statistics_questionnaire').load(encodeURI(url), function(){}).hide().fadeIn();
            }
            if(index == 2){
                var url = "<?php echo e(url('/admin/group/statistics/' . $group_name . '/simulation')); ?>";
                $('#group_statistics_theory').hide();
                $('#group_statistics_questionnaire').hide();
                $('#group_statistics_simulation').load(encodeURI(url), function(){}).hide().fadeIn();
            }
        });
    </script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>