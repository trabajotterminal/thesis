<link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
<!-- Stylesheets -->
<link rel="stylesheet" media="screen" href="<?php echo e(asset('/js/bootstrap/bootstrap.min.css')); ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('/js/mainmenu/menu.css')); ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('/css/default.css')); ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('/css/layouts.css')); ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('/css/font-awesome/css/font-awesome.min.css')); ?>"  type="text/css" />
<link rel="stylesheet" media="screen" href="<?php echo e(asset('/css/responsive-leyouts.css')); ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('/css/et-line-font/et-line-font.css')); ?>">

<!-- Simulation Space Style -->
<link rel="stylesheet" href="<?php echo e(asset('/css/colors/lightblue.css')); ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('/css/category.css')); ?>" type="text/css" />
