<?php $__env->startSection('title', 'Error 404'); ?>
<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <style>
        body { background-color: white;}
        .error-template {padding: 0px 15px;text-align: center;}
        .error-actions {margin-top:0px;margin-bottom:15px;}
        .error-actions .btn { margin-right:10px; }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'index'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="min-height:550px;">
        <div class="row" style="margin-top:50px;">
            <div class="col-md-12">
                <div class="error-template">
                    <h1>¡Uups!</h1>
                    <h2>Error 404</h2>
                    <div class="error-details">
                        <span>Lo sentimos, la página que has solicitado, no la hemos podido encontrar.</span>
                    </div>
                    <img src="<?php echo e(URL::asset('/images/robot.png')); ?>" style="width:200px;height:200px;margin-top:30px;"/>
                    <br><br>
                    <div class="error-actions">
                        <a href="/" class="btn btn-danger btn-md">
                            Volver al inicio
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>