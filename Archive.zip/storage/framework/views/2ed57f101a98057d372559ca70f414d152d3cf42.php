<?php 
    $i = 0;
    $routeQ  = "";
    $routeT  = "";
    $routeS  = "";
    $user = session('user');
 ?>

<?php $__env->startSection('title', 'Categoria'); ?>
<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/cards.css')); ?>" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-overlay bg-opacity-0">
        <div class="container  sec-bpadding-2">
            <br>
            <h3 class="raleway text-black uppercase"><?php echo e($category_name); ?></h1>
            <br>
            <div class="row-md-5" id="category" style="min-height:390px;">
                    <?php while($i < count($topics)): ?>
                        <?php 
                            $count_reference = 0;
                            for($j = 0; $j < count($references[$i]); $j++){
                                if($references[$i][$j] ->  type == 'C'){
                                    $routeQ = $references[$i][$j] ->  approved_route;
                                    $count_reference ++;
                                }
                                if($references[$i][$j] ->  type == 'S'){
                                    $routeS = $references[$i][$j] ->  approved_route;
                                    $count_reference ++;
                                }
                                if($references[$i][$j] ->  type == 'T'){
                                    $routeT = $references[$i][$j] ->  approved_route;
                                    $count_reference ++;
                                }
                            }
                            $randomClassArray   = ['blue', 'purple', 'green', 'yellow', 'red'];
                            $randomClass        = rand(0, count($randomClassArray) - 1);
                            $randomClass        = $randomClassArray[$randomClass];
                         ?>
                        <?php if($i < count($topics)): ?>
                            <div class="col-md-4" style="margin-bottom:10px;">
                                <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
                                <div class="card <?php echo e($randomClass); ?>">
                                    <div class="overlay"></div>
                                    <div class="circle">
                                    </div>
                                    <p style="font-size:30px;"><?php echo e($topics[$i] -> approved_name); ?></p>
                                    <div class="row" style="width:100%;margin-left:50px;margin-top:40px;">
                                        <?php if($count_reference == 3): ?>
                                            <?php if(strlen($routeT)): ?>
                                                <div class="col-md-3">
                                                    <center><p><a href=<?php echo e(url('/theory', $topics[$i] -> approved_name)); ?>>Teoría</a></p></center>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(strlen($routeS)): ?>
                                                <div class="col-md-3">
                                                    <center><p><a href=<?php echo e(url('/simulation', $topics[$i] -> approved_name)); ?>>Simulación</a></p></center>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(strlen($routeQ)): ?>
                                                <?php if($user): ?>
                                                    <div class="col-md-3">
                                                        <center><p><a href=<?php echo e(url('/questionnaire', $topics[$i] -> approved_name)); ?>>Cuestionarios</a></p></center>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if($count_reference == 2): ?>
                                            <?php if(strlen($routeT)): ?>
                                                <div class="col-md-3">
                                                    <center><p><a href=<?php echo e(url('/theory', $topics[$i] -> approved_name)); ?>>Teoría</a></p></center>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(strlen($routeS)): ?>
                                                <div class="col-md-3">
                                                    <center><p><a href=<?php echo e(url('/simulation', $topics[$i] -> approved_name)); ?>>Simulación</a></p></center>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(strlen($routeQ)): ?>
                                                <?php if($user): ?>
                                                    <div class="col-md-3">
                                                        <center><p><a href=<?php echo e(url('/questionnaire', $topics[$i] -> approved_name)); ?>>Cuestionarios</a></p></center>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if($count_reference == 1): ?>
                                            <?php if(strlen($routeT)): ?>
                                                <div class="col-md-3">
                                                    <center><p><a href=<?php echo e(url('/theory', $topics[$i] -> approved_name)); ?>>Teoría</a></p></center>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(strlen($routeS)): ?>
                                                <div class="col-md-3">
                                                    <center><p><a href=<?php echo e(url('/simulation', $topics[$i] -> approved_name)); ?>>Simulación</a></p></center>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(strlen($routeQ)): ?>
                                                <?php if($user): ?>
                                                    <div class="col-md-3">
                                                        <center><p><a href=<?php echo e(url('/questionnaire', $topics[$i] -> approved_name)); ?>>Cuestionarios</a></p></center>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php 
                                $i++
                             ?>
                        <?php endif; ?>
                        <?php 
                            $routeQ = "";
                            $routeT = "";
                            $routeS = "";
                         ?>
                    <?php endwhile; ?>
                    <?php if(count($topics) == 0): ?>
                        <h1 class="text-center" style="padding-top: 150px;">Aún no hay temas para esta categoria.</h1>
                    <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>