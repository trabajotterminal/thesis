<?php $__env->startSection('title', 'Tema'); ?>

<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/et-line-font/et-line-font.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="parallax-section11">
        <h1 style="margin-left:30px;margin-top:30px;"><?php echo e($topic_name); ?></h1>
        <div class="container " style="min-height:380px;">
            <div class="row">
                <div class="col-md-4">
                    <div class="feature-box12">
                        <center><img src="<?php echo e(URL::asset('/images/book_hand.png')); ?>" style="width:100px;height:100px;"/></center>
                        <h3 class="margin-top3">Teoria</h3>
                        <br/>
                        <?php if($references['T']): ?>
                            <?php if(!$is_approval_pending['T']): ?>
                                <form enctype="multipart/form-data" method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/theory/edit/file')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <center><input class="btn btn-default" style="margin-bottom:10px;width:100%;" name="input_file" type="file" id="input_file" accept="text/xml"></center>
                                    <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                    <?php 
                                        $errors = Session::get('file_errors_theory');
                                        if($errors){
                                            for($i = 0; $i < count($errors); $i++){
                                                echo "<p style='margin-left:20px;color:red'>".$errors[$i]."</p>";
                                           }
                                        }
                                     ?>
                                    <?php 
                                        $success = Session::get('file_success_theory');
                                        if($success){
                                            for($i = 0; $i < count($success); $i++){
                                                echo "<p style='margin-left:20px;color:green'>".$success[$i]."</p>";
                                           }
                                        }
                                     ?>
                                    <div class="form-group">
                                        <input class="form-control btn-primary margin-top" style="margin-top:33px;" type="submit" value="Remplazar con un nuevo archivo">
                                    </div>
                                </form>
                                <?php if($needs_approval['T']): ?>
                                    <form  method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/theory/submitReview')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                        <div class="form-group">
                                            <input class="form-control btn-warning" style="margin-top:13px;" type="submit" value="Enviar revisión">
                                        </div>
                                    </form>
                                <?php endif; ?>
                                <form  method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/theory/edit/manually')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                    <a href="#" style="position:absolute;left:5px;bottom:2px;text-decoration:underline;" onclick="$(this).closest('form').submit()">Editar por interfaz</a>
                                </form>
                            <?php else: ?>
                                <p>La teoría está esperando la aprobación del administrador.</p>
                            <?php endif; ?>
                            <form  method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/theory/download')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <a href="#" style="position:absolute;right:5px;bottom:2px;text-decoration:underline;" onclick="$(this).closest('form').submit()">Descargar teoría</a>
                                <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                            </form>
                        <?php else: ?>
                            <p>Sin archivo de teoria.</p>
                            <a class="read-more black" href="<?php echo e(url('creator/topic/'.$topic_name.'/theory')); ?>">Agregar Teoría</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-box12">
                        <center><img src="<?php echo e(URL::asset('/images/chemistry.png')); ?>" style="width:100px;height:100px;"/></center>
                        <h3 class="margin-top3">Simulación</h3>
                        <br/>
                        <?php if($references['S']): ?>
                            <?php if(!$is_approval_pending['S']): ?>
                                <?php if($creation_type['S'] == 'file'): ?>
                                    <form enctype="multipart/form-data" method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/simulation/edit/file')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <center><input class="btn btn-default" style="margin-bottom:10px;width:100%;" name="input_file" type="file" id="input_file" accept="application/zip"></center>
                                        <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                        <?php 
                                            $errors = Session::get('file_errors_simulation');
                                            if($errors){
                                                for($i = 0; $i < count($errors); $i++){
                                                    echo "<p style='margin-left:20px;color:red'>".$errors[$i]."</p>";
                                               }
                                            }
                                         ?>
                                        <?php 
                                            $success = Session::get('file_success_simulation');
                                            if($success){
                                                for($i = 0; $i < count($success); $i++){
                                                    echo "<p style='margin-left:20px;color:green'>".$success[$i]."</p>";
                                               }
                                            }
                                         ?>
                                        <div class="form-group">
                                            <input class="form-control btn-primary margin-top" style="margin-top:33px;" type="submit" value="Remplazar con un nuevo archivo">
                                        </div>
                                    </form>
                                <?php endif; ?>
                                <?php if($needs_approval['S']): ?>
                                        <form  method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/simulation/submitReview')); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                            <div class="form-group">
                                                <input class="form-control btn-warning" style="margin-top:13px;" type="submit" value="Enviar revisión">
                                            </div>
                                        </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <p>La simulación está esperando la aprobación del administrador.</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p>Sin archivos de simulación.</p>
                            <a class="read-more black" href="<?php echo e(url('creator/topic/'.$topic_name.'/simulation')); ?>">Agregar Simulación</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-box12">
                        <center><img src="<?php echo e(URL::asset('/images/test.png')); ?>" style="width:100px;height:100px;"/></center>
                        <h3 class="margin-top3">Cuestionarios</h3>
                        <br/>
                        <?php if($references['C']): ?>
                            <?php if(!$is_approval_pending['C']): ?>
                                <form enctype="multipart/form-data" method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/questionnaire/edit/file')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <center><input class="btn btn-default" style="margin-bottom:10px;width:100%;" name="input_file" type="file" id="input_file"></center>
                                    <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                    <?php 
                                        $errors = Session::get('file_errors_questionnaire');
                                        if($errors){
                                            for($i = 0; $i < count($errors); $i++){
                                                echo "<p style='margin-left:20px;color:red'>".$errors[$i]."</p>";
                                           }
                                        }
                                     ?>
                                    <?php 
                                        $success = Session::get('file_success_questionnaire');
                                        if($success){
                                            for($i = 0; $i < count($success); $i++){
                                                echo "<p style='margin-left:20px;color:green'>".$success[$i]."</p>";
                                           }
                                        }
                                     ?>
                                    <div class="form-group">
                                        <input class="form-control btn-primary margin-top" style="margin-top:33px;" type="submit" value="Remplazar con un nuevo archivo">
                                    </div>
                                </form>
                                <?php if($needs_approval['C']): ?>
                                    <form  method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/questionnaire/submitReview')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                        <div class="form-group">
                                            <input class="form-control btn-warning" style="margin-top:13px;" type="submit" value="Enviar revisión">
                                        </div>
                                    </form>
                                <?php endif; ?>
                                <form  method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/questionnaire/edit/manually')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                    <a href="#" style="position:absolute;left:5px;bottom:2px;text-decoration:underline;" onclick="$(this).closest('form').submit()">Editar por interfaz</a>
                                </form>
                            <?php else: ?>
                                <p>Los cuestionarios están esperando la aprobación del administrador.</p>
                            <?php endif; ?>
                            <form  method="post" class="margin-top-1" action="<?php echo e(url('creator/topic/questionnaire/download')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <a href="#" style="position:absolute;right:5px;bottom:2px;text-decoration:underline;" onclick="$(this).closest('form').submit()">Descargar cuestionario</a>
                                <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                            </form>
                        <?php else: ?>
                            <p>Sin archivos de cuestionario.</p>
                            <a class="read-more black" href="<?php echo e(url('creator/topic/'.$topic_name.'/questionnaire')); ?>">Agregar Cuestionarios</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <br><br><br>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>