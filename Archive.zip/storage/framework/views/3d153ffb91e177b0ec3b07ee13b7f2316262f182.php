<!DOCTYPE html>
<!--
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
-->
<html>
<head>
    <meta charset="utf-8">
    <title>CKEditor Sample</title>
    <script src="<?php echo e(URL::asset('js/ckeditor.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/samples.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/neo.css')); ?>">
</head>
<body>
<div id="editor">
    <h1>Hello world!</h1>
    <p>I'm an instance of <a href="https://ckeditor.com">CKEditor</a>.</p>
</div>
<div id="editor2">
    <h1>Hello world!</h1>
    <p>I'm an instance of <a href="https://ckeditor.com">CKEditor</a>.</p>
</div>
<div id="editor3">
    <h1>Hello world!</h1>
    <p>I'm an instance of <a href="https://ckeditor.com">CKEditor</a>.</p>
</div>
<button onclick="getText();">PRESIONAME</button>
<br><br><br>

</body>
<script>
    var initSample = (function(){ return function() {CKEDITOR.replace('editor', {language: 'es'});};})();
    initSample();
    var initSample = (function(){ return function() {CKEDITOR.replace('editor2', {language: 'es'});};})();
    initSample();
    var initSample = (function(){ return function() {CKEDITOR.replace('editor3', {language: 'es'});};})();
    initSample();

    function getText(){
        var editorData = CKEDITOR.instances.editor3.getData();
        console.warn(editorData);
    }
</script>

</body>
</html>
