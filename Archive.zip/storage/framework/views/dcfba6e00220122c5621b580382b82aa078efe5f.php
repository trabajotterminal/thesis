<script src="<?php echo e(URL::asset('/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('/js/scrolltotop/totop.js')); ?>"></script>
<script src="<?php echo e(asset('/js/category.js')); ?>"></script>

