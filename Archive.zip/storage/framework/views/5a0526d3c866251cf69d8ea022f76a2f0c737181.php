<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/js/smart-forms/smart-forms.css')); ?>" rel="stylesheet" >
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/js/masterslider/style/masterslider.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/js/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'login'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="sec-padding section-light" style="min-height:550px;background-color:white">
        <div class="container white">
            <div class="row">
                <div class="col-md-4 col-centered">
                    <div id="owl-demo3" class="owl-carousel">
                        <div class="item" id="firstItem">
                            <div class="smart-forms bmargin text-box white sec-moreless-padding" style="padding-left: 30px;padding-right: 30px;">
                                <center><h3 class="centered">Inicia Sesión</h3></center>
                                <br/>
                                <br/>
                                <?php echo Form::open(['url' => 'login/user']); ?>

                                <div>
                                    <div class="section">
                                        <label class="field prepend-icon">
                                            <?php echo Form::text('email', '', ['placeholder' => 'usuario  / email', 'class' => 'gui-input']); ?>

                                            <?php echo $errors->first('email', '<p class="help-block" style="color:red;">:message</p>'); ?>

                                            <span class="field-icon"><i class="fa fa-envelope"></i></span> </label>
                                    </div>
                                    <div class="section">
                                        <label class="field prepend-icon">
                                            <?php echo Form::password('password', ['class' => 'gui-input', 'placeholder' => 'Contraseña']); ?>

                                            <?php echo $errors->first('password', '<p class="help-block" style="color:red;">:message</p>'); ?>

                                            <span class="field-icon"><i class="fa fa-unlock-alt"></i></span> </label>
                                    </div>
                                </div>
                                <br>
                                <div class="form-footer">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <center><?php echo Form::submit('Entrar', ['class' => 'button btn-primary orange-2']); ?></center>
                                    <br>
                                    <?php if(session()->has('wrong_credentials')): ?>
                                        <div class="alert alert-danger }}">
                                            <?php echo session('wrong_credentials'); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php echo Form::close(); ?>


                            </div>
                        </div>
                        <div class="item" id="secondItem" style="overflow-y: hidden;">
                            <div class="smart-forms bmargin text-box white sec-moreless-padding" style="padding-left: 30px;padding-right: 30px;">
                                <center><h3 class="centered">Registrate</h3></center>
                                <br/>
                                <br/>
                                <?php echo Form::open(['url' => 'register/user']); ?>

                                <div>
                                    <div class="section">
                                        <label class="field prepend-icon">
                                            <?php echo Form::text('username', '', ['placeholder' => 'Nombre de usuario', 'class' => 'gui-input']); ?>

                                            <span class="field-icon"><i class="fa fa-user"></i></span> </label>
                                            <?php echo $errors->first('username', '<p class="help-block" style="color:red;">:message</p>'); ?>

                                    </div>
                                    <div class="section">
                                        <label class="field prepend-icon">
                                            <?php echo Form::text('register_email', '', ['placeholder' => 'ejemplo@gmail.com', 'class' => 'gui-input']); ?>

                                            <span class="field-icon"><i class="fa fa-envelope"></i></span> </label>
                                            <?php echo $errors->first('register_email', '<p class="help-block" style="color:red;">:message</p>'); ?>

                                    </div>
                                    <div class="section">
                                        <label class="field prepend-icon">
                                            <?php echo Form::password('register_password', ['class' => 'gui-input', 'placeholder' => 'Contraseña']); ?>

                                            <span class="field-icon"><i class="fa fa-unlock-alt"></i></span> </label>
                                            <?php echo $errors->first('register_password', '<p class="help-block" style="color:red;">:message</p>'); ?>

                                    </div>
                                </div>
                                <br>
                                <div class="form-footer">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <center><?php echo Form::submit('Aceptar', ['class' => 'button btn-primary orange-2']); ?></center>
                                    <br>
                                    <?php if(session()->has('user_email_exists')): ?>
                                        <div class="alert alert-danger }}">
                                            <?php echo session('user_email_exists'); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('user_name_exists')): ?>
                                        <div class="alert alert-danger }}">
                                            <?php echo session('user_name_exists'); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="/js/owl-carousel/owl.carousel.js"></script>
    <script src="/js/owl-carousel/custom.js"></script>
    <script>
        $(document).ready(function() {
            var carousel = $("#owl-demo3");
            var indexPage = <?php echo session('indexPage') ?>;
            carousel.trigger('owl.jumpTo', indexPage)
        });
    </script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>