<?php 
    $xmlstring      = file_get_contents('storage/'.$category_name.'/'.$topic_name.'/Cuestionario/latest/cuestionario.xml');
    $try_number     = $tries;
    $xml            = simplexml_load_string($xmlstring);
    $questions      = [];
    $feedbacks      = [];
    $input_images   = [];
    $options        = [];
    $right_answers  = [];
    $i = 0;
    if($tries < $xml['cuestionarios']){
        foreach($xml->children()[$tries] as $index => $bloque) {
            array_push($questions, $bloque -> pregunta);
            array_push($feedbacks, $bloque -> retroalimentacion);
            array_push($input_images, $bloque -> imagen);
            $option_list = [];
            $j = 0;
            foreach($bloque -> opcion  as $option){
                array_push($option_list, $option);
                if($option['value'] == 'true'){
                    $right_answers[$i] = $j + 1;
                }
                ++$j;
            }
            array_push($options, $option_list);
            ++$i;
        }
    }
 ?>

<?php $__env->startSection('title', 'Cuestionario'); ?>
<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <style>
        body{
            color:black;
        }
        .no-margin {
            margin: 0px !important;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="/js/smart-forms/smart-forms.css">
    <link rel="stylesheet" href="/js/masterslider/style/masterslider.css" />
    <link href="/js/owl-carousel/owl.carousel.css" rel="stylesheet">
    <script src="<?php echo e(asset('/js/cytoscape.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <center><h3 class="uppercase weight1 pull margin-top1"><?php echo e($topic_name); ?></h3></center>
    <div class="carousel_holder" id="questionnaire" style="overflow-x: hidden;">
        <div id="owl-demo7" class="owl-carousel" style="min-height:540px;">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="row">
                        <div class="col-md-12" style="height:min-height:450px">
                            <div class="row no-margin">
                                    <?php echo $question; ?>

                            </div>
                            <div class="row no-margin">
                                <center>
                                    <?php $__currentLoopData = $options[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondKey => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="form-check" id="<?php echo e($key); ?>">
                                            <input class="form-check-input" type="radio" name="options_<?php echo e(($key + 1)); ?>" value="<?php echo e(($secondKey + 1)); ?>" <?php echo e($secondKey == 0 ? 'checked': ''); ?>>
                                            <label class="form-check-label" for="options_<?php echo e(($key + 1)); ?>">
                                                <h5><?php echo e($option); ?></h5>
                                            </label>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </center>
                            </div>
                        </div>
                        <?php if($key + 1 == count($questions)): ?>
                            <div class="row">
                                <form action="<?php echo e(url('/questionnaire/'.$topic_name.'/evaluate')); ?>" method="POST" id="questionnaireDone" name="questionnaireDone">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" id="numberOfQuestions" value="<?php echo e(count($questions)); ?>">
                                    <input type="hidden" name="topic_name" value="<?php echo e($topic_name); ?>">
                                    <input type="submit" class="btn btn-success" style="float:right; margin-right:100px;" value="Terminar cuestionario" />
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($questions) == 0): ?>
                    <div class="row" style="margin-top:200px;">
                        <div class="col-md-6 text-center" style="float: none; margin: 0 auto;">
                            <h4>Has agotado los intentos para este tema, vuelve más tarde.</h4>
                        </div>
                    </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript" async src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=AM_CHTML"></script>
    <script src="<?php echo e(asset('/js/questionnaire_simulation_provider.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/owl-carousel/custom.js')); ?>"></script>
    <script>
        var answers     = [];
        var questions   = [];
        var feedbacks   = [];

        $("#questionnaireDone").submit(function(e) {

            var number_of_questions = $('#numberOfQuestions').val();
            for(i = 0; i < number_of_questions; i++) {
                $('#questionnaireDone').append('<input type="hidden" name="user_answers[]" value="'+$('input[name="options_'+(i+1)+'"]:checked').val()+'" />');

            }

            /*var user_answers = [];
            for(var i = 0; i < number_of_questions; i++)
                user_answers.push();
            var url = $('#questionnaireDone').attr('action');
            var topic_name = $('#hiddenTopicName').val();
            var right_answers = answers;
            $.ajax({
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#token").attr('content'));},
                url: url,
                type: 'POST',
                data: {"user_answers": user_answers, "topic_name": topic_name, "right_answers": right_answers, "questions": questions, "feedbacks": feedbacks},
                dataType: 'json',
                success: function( data ){
                    $('#questionnaire').hide();
                    $('#feedback').fadeIn(2000).append(data.view);
                },
                error: function(xhr, status, error) {
                    alert(error);
                },
            });
            e.preventDefault();
            return 0;*/
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>