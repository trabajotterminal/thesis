<?php 
    $xmlstring      = file_get_contents('storage/'.$category_name.'/'.$topic_name.'/Cuestionario/changes/cuestionario.xml');
    $xml            = simplexml_load_string($xmlstring);
    $questions      = [];
    $feedbacks      = [];
    $input_images   = [];
    $options        = [];
    $right_answers  = [];
    $tries          = $xml['cuestionarios'];
    $i = 0;
    for($k = 0; $k < $tries; $k++){
        foreach($xml->children()[$k] as $index => $bloque) {
            array_push($questions, $bloque -> pregunta);
            array_push($feedbacks, $bloque -> retroalimentacion);
            $option_list = [];
            $j = 0;
            foreach($bloque -> opcion  as $option){
                array_push($option_list, $option);
                if($option['value'] == 'true'){
                    $right_answers[$i] = $j + 1;
                }
                ++$j;
            }
            array_push($options, $option_list);
            ++$i;
        }
    }
 ?>

<?php $__env->startSection('title', 'Revisión.'); ?>
<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript" async src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=AM_CHTML"></script>
    <link rel="stylesheet" type="text/css" href="/js/smart-forms/smart-forms.css">
    <link rel="stylesheet" href="/js/masterslider/style/masterslider.css" />
    <link href="/js/owl-carousel/owl.carousel.css" rel="stylesheet">
    <script src="<?php echo e(asset('/js/cytoscape.js')); ?>"></script>
    <style>
        body{
            overflow-x: hidden;
            color: black;
        }
        .no-margin {
            margin: 0px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h4 class="margin-left-5 margin-top3">Cuestionario / <?php echo e($topic_name); ?></h4>
    <div class="carousel_holder">
        <div id="owl-demo7" class="owl-carousel" style="min-height:490px;">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="row">
                        <div class="col-md-12" style="min-height:450px;">
                            <div class="row no-margin" style="height:auto; margin-bottom:0px;padding-left:30px;padding-right:50px;">
                                <?php echo $question; ?>

                            </div>
                            <div class="row no-margin" style="margin-left:100px;">
                                <center>
                                <?php $__currentLoopData = $options[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondKey => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="form-check" id="<?php echo e($key); ?>">
                                            <input class="form-check-input" type="radio" name="options_<?php echo e(($key + 1)); ?>" value="">
                                            <label class="form-check-label" for="options_<?php echo e(($key + 1)); ?>">
                                                <h5><?php echo e($option); ?></h5>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </center>
                            </div>
                        </div>
                        <div class="col-md-6 bmargin">

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="row margin-top3" style="margin-bottom:30px;">
        <div class="col-md-12">
            <center>
                <div class="form-group" style="margin:0px;padding:0px;">
                    <form action="<?php echo e(url('admin/notification/questionnaire/resolve')); ?>" id="notificationForm" method="POST">
                        <textarea class="form-control" rows="2" style="width:450px;" name="comment" placeholder="Escribe una retroalimentación para <?php echo e($creator_username); ?>."></textarea>
                        <br>
                        <input type="submit" name="accept" class="btn btn-success" value="Aceptar cuestionario">
                        <input type="submit" name="decline" class="btn btn-danger" style="margin-left:30px;" value="Rechazar cuestionario">
                    </form>
                </div>
            </center>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(asset('/js/questionnaire_simulation_provider.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/owl-carousel/custom.js')); ?>"></script>
    <script>
        var action  = "";
        var message = $('textarea[name="comment"]').val();
        var notification_id = <?php echo json_encode($notification -> id) ?>;
        var url = $("#notificationForm").attr('action');
        $("#notificationForm").submit(function(e){
            message = $('textarea[name="comment"]').val();
            e.preventDefault();
            e.stopImmediatePropagation();
            $.ajax ({
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#token").attr('content'));},
                type: 'POST',
                data: {'notification_id': notification_id, 'action': action.name, 'message': message},
                url: url,
                datatype: "json",
                success: function(data) {
                    window.location = "/";
                }
            });
            return false;
        });

        $(".btn").click(function(e){
            action = this;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>