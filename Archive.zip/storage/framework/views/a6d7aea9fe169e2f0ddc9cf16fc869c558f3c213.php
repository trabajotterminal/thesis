<?php 
    $routeQ             = "";
    $routeS             = "";
    $routeT             = "";
    $user = session('user');
 ?>

<?php $__env->startSection('title', 'Búsqueda'); ?>
<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/cards.css')); ?>" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'index'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="min-height:550px;">
        <div class="row">
            <div class="col-md-6">
                <br>
                <h4>Resultados para: <u><?php echo e($input); ?></u></h4>
                <?php if(count($search_results) == 0 && $should_display_predicted_word): ?>
                    <h5>Quizás quisiste decir: <a href="/search?input_search=<?php echo e($predicted_word); ?>" style="color:blue"><?php echo e($predicted_word); ?></a></h5>
                <?php endif; ?>
                <hr>
            </div>
        </div>
        <div class="row" style="margin-top:30px;">
            <?php $__currentLoopData = $search_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $randomClassArray   = ['blue', 'purple', 'green', 'yellow', 'red'];
                    $randomClass        = rand(0, count($randomClassArray) - 1);
                    $randomClass        = $randomClassArray[$randomClass];
                 ?>
                <div class="col-md-4" style="margin-bottom:10px;">
                    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
                    <div class="card <?php echo e($randomClass); ?>">
                        <div class="overlay"></div>
                        <div class="circle">
                        </div>
                        <p style="font-size:30px;"><?php echo e($result -> topic_name); ?></p>
                        <?php 
                            for($j = 0; $j < count($references[$key]); $j++){
                                if($references[$key][$j] ->  type == 'C'){
                                    $routeQ = $references[$key][$j] -> approved_route;
                                }
                                if($references[$key][$j] ->  type == 'S'){
                                    $routeS = $references[$key][$j] -> approved_route;
                                }
                                if($references[$key][$j] ->  type == 'T'){
                                    $routeT = $references[$key][$j] -> approved_route;
                                }
                            }
                         ?>
                        <div class="row" style="width:110%;margin-left:50px;margin-top:40px;">
                            <?php if(strlen($routeT)): ?>
                                <div class="col-md-3">
                                    <center><p><a href=<?php echo e(url('/theory', $result -> topic_name)); ?>>Teoría</a></p></center>
                                </div>
                            <?php endif; ?>
                            <?php if(strlen($routeS)): ?>
                                <div class="col-md-3">
                                    <center><p><a href=<?php echo e(url('/simulation', $result -> topic_name)); ?>>Simulación</a></p></center>
                                </div>
                            <?php endif; ?>
                            <?php if(strlen($routeQ)): ?>
                                <?php if($user): ?>
                                    <div class="col-md-3">
                                        <center><p><a href=<?php echo e(url('/questionnaire', $result -> topic_name)); ?>>Cuestionarios</a></p></center>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php 
                    $routeQ = "";
                    $routeT = "";
                    $routeS = "";
                 ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($search_results) == 0): ?>
                <div class="col-md-12">
                    <h1 class="text-center" style="padding-top: 70px;">No se encontraron resultados.</h1>
                </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>