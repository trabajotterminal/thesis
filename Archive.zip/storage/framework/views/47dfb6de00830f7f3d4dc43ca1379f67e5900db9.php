<?php $__env->startSection('title', 'Error'); ?>

<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <style>
        body{
            margin: 0;
            padding: 0;
            background: #6b4ae3;
            font-family: Arial, Helvetica, sans-serif;
        }
        *{
            margin: 0;
            padding: 0;
        }
        p{
            font-size: 12px;
            color: #373737;
            font-family: Arial, Helvetica, sans-serif;
            line-height: 18px;
        }
        p a{
            color: #218bdc;
            font-size: 12px;
            text-decoration: none;
        }
        a{
            outline: none;
        }
        .f-left{
            float:left;
        }
        .f-right{
            float:right;
        }
        .clear{
            clear: both;
            overflow: hidden;
        }
        #block_error{
            width: 845px;
            height: 384px;
            border: 1px solid #cccccc;
            margin: 72px auto 0;
            -moz-border-radius: 4px;
            -webkit-border-radius: 4px;
            border-radius: 4px;
            background: #fff url(http://www.ebpaidrev.com/systemerror/block.gif) no-repeat 0 51px;
        }
        #block_error div{
            padding: 100px 40px 0 186px;
        }
        #block_error div h2{
            color: #218bdc;
            font-size: 24px;
            display: block;
            padding: 0 0 14px 0;
            border-bottom: 1px solid #cccccc;
            margin-bottom: 12px;
            font-weight: normal;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => ''], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="block_error" style="min-height:500px;">
        <div>
            <h2>¡Uuuups!</h2>
            <h5>Parece que algo malo malo ocurrió, inténta volver más tarde.</h5>
            <h5>Nuestro equipo recibirá el reporte del error y trabajara en ello lo más pronto posible.</h5>
            <center>
                <img src="<?php echo e(URL::asset('/images/barricade.png')); ?>" style="width:120px;height:120px;margin-top:30px;"/>
                <img src="<?php echo e(URL::asset('/images/barricade.png')); ?>" style="width:120px;height:120px;margin-top:30px;"/>
                <img src="<?php echo e(URL::asset('/images/barricade.png')); ?>" style="width:120px;height:120px;margin-top:30px;"/>
                <img src="<?php echo e(URL::asset('/images/barricade.png')); ?>" style="width:120px;height:120px;margin-top:30px;"/>
            </center>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>