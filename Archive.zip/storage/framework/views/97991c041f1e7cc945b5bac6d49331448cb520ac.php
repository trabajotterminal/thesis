<?php $__env->startSection('title', 'Simulación'); ?>

<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__currentLoopData = $cssFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cssFile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
            $cssFile = substr($cssFile, strpos($cssFile, '/') + 1);
         ?>
        <link rel="stylesheet" href="<?php echo e(asset('/storage/'.$cssFile)); ?>" type="text/css" />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="simulator"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php 
        for($i = 0; $i < count($jsFiles); $i++){
            asset('storage/'.$jsFiles[$i]);
        }
     ?>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>