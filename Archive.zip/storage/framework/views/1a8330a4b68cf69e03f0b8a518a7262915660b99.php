<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8">
    <meta id="token" name="token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldContent('statics-css'); ?>
</head>
<body>
<div class="site_wrapper">
    <?php echo $__env->yieldContent('menu'); ?>
    <div class="clearfix"></div>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="clearfix"></div>
    <?php echo $__env->yieldContent('footer'); ?>
    <div class="clearfix"></div>
    <a href="#" class="scrollup pink-3"></a>
</div>
<?php echo $__env->yieldContent('statics-js'); ?>
</body>
</html>