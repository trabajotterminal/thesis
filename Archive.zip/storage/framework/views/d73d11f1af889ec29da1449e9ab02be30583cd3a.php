<?php 
    $menu_classes       = [];
    $menu_classes[0]    = $page == 'index' ? 'active' : '';
    $menu_classes[1]    = $page == 'category' ? 'active' : '';
    $menu_classes[2]    = $page == 'login' ? 'active' : '';
    $menu_classes[3]    = $page == 'login' ? 'active' : '';
    $user               = session('user');
    $user_type          = session('user_type');
    $notification_count = count($notifications);
    if($unread_notifications){
        $unread_notifications = '('.$unread_notifications.')';
    }else{
        $unread_notifications = '';
    }
 ?>
<style>
    .navbar-default .dropdown-menu.notify-drop {
        background-color: #fff;
        max-height: 360px;
        overflow-y: scroll;
    }
</style>
<div id="header" style="background-color:#f6f6f6">
    <div class="container orange2" >
        <div class="navbar lightblue-3 navbar-default yamm">
            <div class="navbar-header">
                <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle two three"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                <a href="<?php echo e(URL('/')); ?>" class="navbar-brand less-top-padding"><!--<img src="/images/logoEscom.png" style="width:80px;height:50px;"alt=""/>--></a> </div>
                <div id="navbar-collapse-grid" class="navbar-collapse collapse pull-right">
                    <ul class="nav pink-3 navbar-nav">
                        <li><a href="<?php echo e(URL('/')); ?>" class="dropdown-toggle <?php echo e($menu_classes[0]); ?>">Inicio</a></li>
                        <?php if($user != null): ?>
                            <?php if($user_type == 'student'): ?>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle <?php echo e($menu_classes[1]); ?>">Categorias</a>
                                    <ul class="dropdown-menu" role="menu">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="dropdown-submenu"><a href="<?php echo e(url('/category/'.$category -> approved_name)); ?>"><?php echo e($category -> approved_name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($categories) == 0): ?>
                                                <li class="dropdown-submenu"><a href="#">Aún no hay categorias disponibles</a></li>
                                        <?php endif; ?>
                                        <li class="dropdown-submenu mul" style="display:none;">
                                            <a tabindex="-1" href="#">No idea</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo e(URL('/profile')); ?>" class="dropdown-toggle <?php echo e($menu_classes[2]); ?>">Perfil</a></li>
                                <li><a href="<?php echo e(URL('/logout')); ?>" class="dropdown-toggle">Cerrar Sesión</a></li>
                            <?php endif; ?>
                            <?php if($user_type == 'creator'): ?>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle  <?php echo e($menu_classes[1]); ?>">Administrar</a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li> <a href="<?php echo e(URL('/creator/categories')); ?>">Mis categorias</a> </li>
                                        <li> <a href="<?php echo e(URL('/creator/topics')); ?>">Mis temas</a> </li>
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle">Notificaciones <b><?php echo e($unread_notifications); ?></b></a>
                                    <ul class="dropdown-menu notify-drop">
                                        <div class="drop-content">
                                            <?php if($notification_count == ''): ?>
                                                <li style="margin-left:20px;">Sin notificaciones</li>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li style="overflow-x: hidden;">
                                                        <?php if($notification -> seen == false): ?>
                                                            <div class="row" style="background-color: #edf2fa;">
                                                        <?php else: ?>
                                                            <div class="row">
                                                        <?php endif; ?>
                                                            <div class="col-md-3 col-sm-3 col-xs-3" style="width:60px;height:60px;margin-left:10px;">
                                                                <?php if($notification -> type == 'MP'): ?>
                                                                    <center><img src="<?php echo e(URL::asset('/images/accepted.png')); ?>" style="width:25px;height:25px;margin-top:10px;"/></center>
                                                                <?php endif; ?>
                                                                <?php if($notification -> type == 'MN'): ?>
                                                                    <center><img src="<?php echo e(URL::asset('/images/cross.png')); ?>" style="width:25px;height:25px;margin-top:10px;"/></center>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-md-9 col-sm-9 col-xs-9">
                                                                <?php 
                                                                    $action = "";
                                                                    $object = "";
                                                                    $image  = "";
                                                                    if($notification -> type == 'MP'){
                                                                        $action = "aprobo";
                                                                    }
                                                                    if($notification -> type == 'MN'){
                                                                        $action = "rechazó";
                                                                    }
                                                                    if($notification -> additional_params == 'E'){
                                                                        $action.= " la edición";
                                                                    }
                                                                    if($notification -> additional_params == 'A'){
                                                                        $action.= " la creación";
                                                                    }
                                                                    if($notification -> additional_params == 'D'){
                                                                        $action.= " la eliminación";
                                                                    }

                                                                    if($notification -> topic_id){
                                                                        $object = " de un tema";
                                                                    }
                                                                    if($notification -> category_id){
                                                                        $object = "de una categoria";
                                                                    }
                                                                    if($notification -> reference_id){
                                                                        $object = "del contenido de un tema";
                                                                    }
                                                                 ?>
                                                                <p>
                                                                    <?php echo e($sender_names[$key]); ?> <span><?php echo e($action); ?></span> <?php echo e($object); ?>.
                                                                </p>
                                                                <p><u><a href="<?php echo e(url('creator/notification/'.$notification -> id)); ?>" style="color: #34495e ">Ver más</a></u></p>
                                                                <hr>
                                                            </div>
                                                        </div>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </ul>
                                </li>
                                <li><a href="/logout" class="dropdown-toggle"  <?php echo e($menu_classes[3]); ?>">Cerrar Sesión</a></li>
                            <?php endif; ?>
                            <?php if($user_type == 'admin'): ?>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle">Notificaciones <b><?php echo e($unread_notifications); ?></b></a>
                                        <ul class="dropdown-menu notify-drop">
                                            <div class="drop-content">
                                                <?php if($notification_count == ''): ?>
                                                    <li style="margin-left:20px;">Sin notificaciones</li>
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <div class="col-md-2 col-sm-2 col-xs-2" style="width:30px;height:30px;">
                                                                <center><span style="font-size:40px;text-align: center;vertical-align: middle;line-height: 40px;"><?php echo e($sender_names[$key][0]); ?></span></center>
                                                            </div>
                                                            <div class="col-md-10 col-sm-10 col-xs-10">
                                                                <?php 
                                                                    $action = "";
                                                                    $object = "";
                                                                    if($notification -> type == 'A')
                                                                        $action = "agregó";
                                                                    if($notification -> type == 'E')
                                                                        $action = 'editó';
                                                                    if($notification -> type == 'D')
                                                                        $action = 'eliminó';
                                                                    if($notification -> category_id)
                                                                        $object = " una categoria.";
                                                                    if($notification -> topic_id)
                                                                        $object = ' un tema';
                                                                    if($notification -> reference_id){
                                                                        $object = ' contenido de un tema';
                                                                    }
                                                                 ?>
                                                                <p><?php echo e($sender_names[$key]); ?> <?php echo e($action); ?> <?php echo e($object); ?></p>
                                                                <?php if($notification -> reference_id): ?>
                                                                    <?php if($reference_type[$key] == 'T'): ?>
                                                                        <p><u><a href="<?php echo e(url('admin/notification/theory/'.$notification -> id)); ?>" style="color: #34495e ">Revisar ahora</a></u></p>
                                                                    <?php endif; ?>
                                                                    <?php if($reference_type[$key] == 'C'): ?>
                                                                        <p><u><a href="<?php echo e(url('admin/notification/questionnaire/'.$notification -> id)); ?>" style="color: #34495e ">Revisar ahora</a></u></p>
                                                                    <?php endif; ?>
                                                                    <?php if($reference_type[$key] == 'S'): ?>
                                                                        <p><u><a href="<?php echo e(url('admin/notification/simulation/'.$notification -> id)); ?>" style="color: #34495e ">Revisar ahora</a></u></p>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <p><u><a href="<?php echo e(url('admin/notification/'.$notification -> id)); ?>" style="color: #34495e ">Revisar ahora</a></u></p>
                                                                <?php endif; ?>

                                                                <hr>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </ul>
                                    </li>
                                    <li><a href="/admin/statistics" class="dropdown-toggle  <?php echo e($menu_classes[2]); ?>">Ver estadisticas</a></li>
                                    <li><a href="/logout" class="dropdown-toggle"  <?php echo e($menu_classes[3]); ?>">Cerrar Sesión</a></li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="dropdown"> <a href="#" class="dropdown-toggle <?php echo e($menu_classes[1]); ?>">Categorias</a>
                                <ul class="dropdown-menu" role="menu">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="dropdown-submenu"><a href="<?php echo e(url('/category/'.$category -> approved_name)); ?>"><?php echo e($category -> approved_name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($categories) == 0): ?>
                                        <li class="dropdown-submenu"><a href="#">Aún no hay categorias disponibles</a></li>
                                    <?php endif; ?>
                                    <li class="dropdown-submenu mul" style="display:none;">
                                        <a tabindex="-1" href="#">No idea</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="/login" class="dropdown-toggle <?php echo e($menu_classes[2]); ?>">Inicia Sesión</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>