<?php 
    $glances_theory_topics = array_column($theory_glances_array, 'approved_name');
    $seen_topics = count($glances_theory_topics);
    $percentage = $total_topics > 0  ? $seen_topics * 100 / $total_topics: 0;
 ?>

<style>body{overflow-x: hidden;}</style>
<link rel="stylesheet" href="<?php echo e(asset('/css/shortcodes.css')); ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('css/et-line-font/et-line-font.css')); ?>">
<div class="row margin-left-1">
    <?php $__currentLoopData = $categories_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row" class="margin-top3">
            <?php if(count($topics_array[$key]) == 0): ?>
                <div class="col-md-6">
                    <h3  class="margin-left-1 margin-top3"><?php echo e($category); ?></h3>
                </div>
                <div class="col-md-6">
                    <h4 class="margin-top4">Ésta categoria aún no cuenta con ningún tema disponible.</h4>
                </div>
            <?php else: ?>
                <div class="row">
                    <h3 class="margin-left-4 margin-top3"><?php echo e($category); ?></h3>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $topics_array[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-2">
                            <div class="feature-box-103 text-center bmargin">

                                <?php if(in_array($topic, $glances_theory_topics)): ?>
                                    <div class="iconbox-medium round" style="background-color:#2ecc71;">
                                        <span class="fa-stack">
                                            <i class="fa fa-check fa-stack-1x"></i>
                                            <i class="fa fa-check fa-stack-1x"></i>
                                        </span>
                                    </div>
                                    <br>
                                    <h5><?php echo e($topic); ?></h5>
                                <?php else: ?>
                                    <div class="iconbox-medium round" style="background-color:#e74c3c;">

                                        <span class="fa-stack fa-lg">
                                          <i class="fas fa-eye-slash fa-stack-1x" style="color:white;"></i>
                                        </span>
                                    </div>
                                    <h5><?php echo e($topic); ?></h5>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="sh-divider-line doubble light  margin"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<h3 class="margin-left-3 margin-top1">Estadisticas generales - Teoría.</h3>
<div id="chartContainerTheory" style="height: 300px; width: 100%;margin-top:60px;"></div>
<script>
    $(document).ready(function(){
        CanvasJS.addColorSet("greenShades",
            [
                "#2ECC71",
                "#CD6155",
            ]
        );
        var chart = new CanvasJS.Chart("chartContainerTheory", {
            colorSet: "greenShades",
            animationEnabled: true,
            title:{
                text: "",
                horizontalAlign: "left"
            },
            data: [{
                type: "doughnut",
                startAngle: 60,
                //innerRadius: 60,
                indexLabelFontSize: 17,
                indexLabel: "{label} - #percent%",
                toolTipContent: "<b>{label}:</b> {y} (#percent%)",
                dataPoints: [
                    { y: <?php echo $percentage ?>, label: "Temas vistos" },
                    { y: 100 - <?php echo $percentage ?>, label: "Temas sin revisar" },
                ]
            }]
        });
        chart.render();
    });
</script>

