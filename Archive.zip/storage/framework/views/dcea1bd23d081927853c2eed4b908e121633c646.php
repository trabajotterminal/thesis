<?php 
    $xml                = $xmlFilePath[0];
    //remove public/ by storage/.
    $xml                = substr($xml, strpos($xml, '/') + 1);
    $T = file_get_contents("storage/" . $xml);
    $title_start_position = strpos($T, '<titulo>');
    $title_end_position = strpos($T, '</titulo>');
    $title = substr($T, $title_start_position, $title_end_position - $title_start_position);
    $T = substr($T, strpos($T, '</titulo>') + 9);
    $T = str_replace(']]>', '', $T);
    $T = str_replace('<subtitulo>', '<h4>', $T);
    $T = str_replace('</subtitulo>', '</h4>', $T);

    $T = str_replace('<parrafo><![CDATA[', '<p>', $T);
    $T = str_replace('</parrafo>', '</p><br>', $T);

    $T = preg_replace('/(<codigo.*?>)/', '<pre><code>', $T);
    $T = str_replace('</codigo>', '</pre></code><br><br>', $T);

    $T = str_replace('<referencia>', '', $T);
    $T = str_replace('</referencia>', '', $T);

    $T = str_replace('<encabezado>', '<b><p>', $T);
    $T = str_replace('</encabezado>', '<b></p>', $T);

    $T = str_replace('<link>', '<a href="#" style="color:#235cba;">', $T);
    $T = str_replace('</link>', '</a>', $T);

    $T = str_replace('<teoria>', '', $T);
    $T = str_replace('</teoria>', '', $T);
    $user_id            = session('user_id');
    $user_type       = session('user_type');
 ?>

<?php $__env->startSection('title', 'Revisión'); ?>

<?php $__env->startSection('statics-css'); ?>
    <?php echo $__env->make('layouts/statics-css-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/monokai-sublime.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/summernote-ext-emoji-ajax.css')); ?>"  type="text/css" />
    <style>
        body{
            overflow-x: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('layouts/menu', ['page' => 'category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container" style="min-height:550px;">
            <h4 style="margin-top:40px;">Teoría <?php echo e($action); ?> por <?php echo e(strtolower($creator_username)); ?> para el tema: <?php echo e($topic_name); ?></h4>
            <div class="divider-line solid light opacity-7"></div>
            <div class="row sec-moreless-padding slide-controls-color-7">
                <div class="col-xs-12 text-left">
                    <h4 class="uppercase oswald">
                        <?php 
                            echo $title;
                         ?>
                    </h4>
                    <div class="divider-line solid light opacity-7"></div>
                    <div class="clearfix"></div>
                    <div class="text-box border padding-1">
                        <div class="feature-box-75" style=" text-align: justify;">
                            <?php 
                                echo $T;
                             ?>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <center>
                        <div class="form-group" style="margin:0px;padding:0px;">
                            <form action="<?php echo e(url('admin/notification/theory/resolve')); ?>" id="notificationForm" method="POST">
                                <textarea class="form-control" rows="2" style="width:450px;" name="comment" placeholder="Escribe una retroalimentación para <?php echo e($creator_username); ?>."></textarea>
                                <br>
                                <input type="submit" name="accept" class="btn btn-success" value="Aceptar">
                                <input type="submit" name="decline" class="btn btn-danger" style="margin-left:30px;" value="Rechazar">
                            </form>
                        </div>
                    </center>
                </div>
            </div>
            <br><br>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statics-js'); ?>
    <?php echo $__env->make('layouts/statics-js-1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(asset('/js/highlight.pack.js')); ?>"></script>
    <script>hljs.initHighlightingOnLoad();</script>
    <script src="<?php echo e(asset('/js/scripts/functions.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" async src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=AM_CHTML"></script>
    <script>
        var action  = "";
        var message = $('textarea[name="comment"]').val();
        var notification_id = <?php echo json_encode($notification -> id) ?>;
        var url = $("#notificationForm").attr('action');
        $("#notificationForm").submit(function(e){
        message = $('textarea[name="comment"]').val();
        e.preventDefault();
        e.stopImmediatePropagation();
        $.ajax ({
            beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $("#token").attr('content'));},
            type: 'POST',
            data: {'notification_id': notification_id, 'action': action.name, 'message': message},
            url: url,
            datatype: "json",
            success: function(data) {
                window.location = "/";
            }
        });
        return false;
        });

        $(".btn").click(function(e){
        action = this;
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>