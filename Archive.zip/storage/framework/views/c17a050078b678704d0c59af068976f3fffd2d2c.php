<?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="pagenation-holder">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h3 style="font-weight: 100;"><?php echo e($name); ?></h3>
                    </div>
                    <div class="col-md-6 text-right">
                        <div class="row">
                            <?php echo Form::open(['url' => 'creator/categories/edit']); ?>

                            <input name="submit" value="Editar" class="btn btn-primary" type="submit" style="text-align: center;width:200px;">
                            <?php echo Form::close(); ?>

                            <?php echo Form::open(['url' => 'creator/categories/delete']); ?>

                            <input name="submit" value="Eliminar" class="btn btn-danger" type="submit" style="text-align: center;width:200px;">
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>