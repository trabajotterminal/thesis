<?php 
    $groups_table    = [];
    $ranking_table  = [];
    $index          = 0;
    for($i = 0; $i < count($ranked_groups); $i++){
        $groups_table[$index] = $ranked_groups[$i] -> name;
        $ranking_table[$index++] = $ranked_groups[$i] -> points;
    }
    for($i = 0; $i < count($non_ranked_groups); $i++){
        $groups_table[$index] = $non_ranked_groups[$i] -> name;
        $ranking_table[$index++] = 'Sin registros';
    }
 ?>
<style>
    .green-color{
        background:   #2ecc71   !important;
    }
</style>
<table id="table_groups" class="table table-striped" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th class="green-color">Posición</th>
        <th class="green-color">Grupo</th>
        <th class="green-color">Puntuación</th>
        <th class="green-color"></th>
    </tr>
    </thead>
    <tbody height="300px">
    <?php $__currentLoopData = $groups_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><h4><?php echo e($key + 1); ?></h4></td>
            <td><?php echo e($groups_table[$key]); ?></td>
            <td><?php echo e($ranking_table[$key]); ?></td>
            <td><a href="<?php echo e(url('admin/statistics/group/'. $groups_table[$key])); ?>"><button type="button" class="btn btn-default btn-xs">Ver perfil</button></a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script>
    $(document).ready(function() {
        $('#table_groups').dynatable();
    });
</script>