<link rel="stylesheet" href="<?php echo e(URL::asset('/css/tagit.ui-zendesk.css')); ?>"  type="text/css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo e(URL::asset('/js/tag-it.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(URL::asset('/css/jquery.tagit.css')); ?>"  type="text/css" />