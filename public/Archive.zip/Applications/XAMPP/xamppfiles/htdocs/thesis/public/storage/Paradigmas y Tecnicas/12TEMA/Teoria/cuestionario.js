{
  "bloques" : [
    {
      "pregunta": "¿Dada la siguiente Grafica N - completa, cuantas aristas existen?",
      "opciones": [
        { "valor": "4", "correcto":true},
        { "valor": "2", "correcto":false},
        { "valor": "3", "correcto":false}
      ],
      "simulacion": "[{'group': 'nodes','data': {'id': '1'}},{'group': 'nodes','data': {'id': '2'}},{'group': 'nodes','data': {'id': '3'}},{'group': 'nodes','data': {'id': '4'}},{ 'group':'edges','data':{'id':'e0','source':'1','target':'2'}}]"
    },
    {
      "pregunta": "¿cual es el nombre correcto?",
      "opciones": [
        { "valor": "John", "correcto":true},
        { "valor": "Anna", "correcto":false},
        { "valor": "Peter", "correcto":false}
      ],
      "simulacion": "[{'group': 'nodes','data': {'id': '1'}},{'group': 'nodes','data': {'id': '2'}},{'group': 'nodes','data': {'id': '3'}}]"
    },
    {
      "pregunta": "¿cual es el nombre correcto?",
      "opciones": [
        { "valor": "John", "correcto":true},
        { "valor": "Anna", "correcto":false},
        { "valor": "Peter", "correcto":false}
      ],
      "simulacion": "[{'group': 'nodes','data': {'id': '1'}},{'group': 'nodes','data': {'id': '2'}},{'group': 'nodes','data': {'id': '3'}}]"
    }
  ]
}