$(document).ready(function() {
    $("#category").css({"position":"relative","opacity": 0, "top":"+=100"});
    $("#category").animate({top:0, opacity:1}, 1200);
});