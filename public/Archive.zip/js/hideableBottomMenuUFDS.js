$(document).ready(function(){ 
	document.getElementById("gear").click(); 
});